<?php

session_start();

if(!$_SESSION['login']){
   header("location:login.php");
   die;
}

ini_set('display_errors',1);


define("HOST",'localhost');
$db=mysqli_connect(HOST,'wp_user','password','ciss227');


include 'header2.php';

$query="select item_id, item_name from item order by item_name";
$result=mysqli_query($db,$query);

echo '<div class="content">';
echo '<form method="POST" action="decision.php">';
echo '<h2>Select An Item to View</h2>';
echo '<select name="item_id" autofocus>';
echo '<option value="NONE">SELECT ITEM</option>';

while($row=mysqli_fetch_array($result)) {
    
    echo "<option value='".$row['item_id']."'>".$row['item_name']."</option><br>";
}

echo '</select>';
echo '<div class = "error"><br /><br />';
echo 'Please select a valid item!';
echo '<br /><br />';
echo '</div>';

echo '<input type="submit" value="View Item Details">';

echo "<input type='button' onclick='location.href=\"logout.php\";' value='Log Out'>";

echo '</form>';

echo '</div>';
echo '</body>';
echo '</html>';

?>
