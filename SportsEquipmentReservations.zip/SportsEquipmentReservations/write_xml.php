<?php
session_start();

if(!$_SESSION['login']){
   header("location:login.php");
   die;
}

//ini_set('display_errors',1);

//Use this for testing from mamp 
define("HOST",'localhost');
$db=mysqli_connect(HOST,'wp_user','password','ciss228');

if($db) {
    


//Runs query on item table in ciss227 database and selects all fields
    $query="select * from item";
    $result=mysqli_query($db,$query);

    $fp=fopen('item_inventory.xml','w');  //Opens file to write to

    //Writes header
    $header="<?xml version=\"1.0\"?>\n<!DOCTYPE item SYSTEM \"item_inventory.dtd\">\n";
    $header.="<?xml-stylesheet type=\"text/css\" href=\"item_inventory.css\"?>\n";
    $header.="<item_inventory>\n";
    $written=fwrite($fp,$header);

    $xml_data="";  //String variable to store xml album elements


    while($row=mysqli_fetch_array($result)) {  //Loops through results
	   $xml_data .= "  <item id='".$row["item_id"]."'>\n";  //Appends opening item tag with id
	   $xml_data .= "    <image>images/".$row["item_image"]."</image>\n";  
	   $xml_data .= "    <name>".$row["item_name"]."</name>\n";
	   $xml_data .= "    <brand>".$row["item_brand"]."</brand>\n";
       $xml_data .= "    <price>".$row["item_price"]."</price>\n";
	   $xml_data .= "    <quantity>".$row["item_quantityonhand"]."</quantity>\n";
	   $xml_data .= "  </item>\n";
	}
    
    //Appends an empty item to item_inventory.xml to be displayed when the
    //user does not choose an item from the select list.
    $xml_data .= "<item id='NONE'>\n";
    $xml_data .= "  <image>images/image_not_available.jpg</image>\n";
    $xml_data .= "  <name>Not Available</name>\n";
    $xml_data .= "  <brand>Not Avaialable</brand>\n";
    $xml_data .= "  <price>0</price>\n";
    $xml_data .= "  <quantity>0</quantity>\n";
    $xml_data .= "</item>\n";

    $written=fwrite($fp,$xml_data);  //Writes xml tags to document

    $footer="</item_inventory>\n";  //Writes closing tag to document
    $written=fwrite($fp,$footer);
    fclose($fp);

    //Runs transform on xml document
    $xslDoc = new DOMDocument();
    $xslDoc->load("item_inventory.xsl");

    $xmlDoc = new DOMDocument();
    $xmlDoc->load("item_inventory.xml");

    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);

    //$proc->setParameter('', 'itemid', $_POST["item_id"]);
    $proc->setParameter('', 'itemid', $_SESSION['item_id']);

    echo $proc->transformToXML($xmlDoc);
}
else {
        header("Location: failure_message.php");


    
}


?>
