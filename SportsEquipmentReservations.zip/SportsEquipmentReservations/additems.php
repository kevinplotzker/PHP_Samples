<?php

session_start();

if(!$_SESSION['login']){
   header("location:login.php");
   die;
}

include"header3.php";

$item=$_GET["iid"];
$qty=$_GET["qtyReserved"];
$price = $_GET["iprice"];

$userid = $_SESSION["userid"];

define("HOST",'localhost');
$db=mysqli_connect(HOST,'wp_user','password','ciss227');

echo "<div id='results'>";

if($db) {

    $query = "select item_quantityonhand from item where
              item_id = '".$item."'";
    $result = mysqli_query($db, $query);
    $row = mysqli_fetch_row($result);
    $quantityonhand = $row[0];

    if ($quantityonhand >= $qty) {
        $newqty = $quantityonhand - $qty;
        $query = "UPDATE item
                SET item_quantityonhand = '".$newqty."'
                WHERE item_id = '".$item."'";
    
        if (mysqli_query($db, $query)) {
            $totalamt = $qty * $price;
            $query = "INSERT INTO reservation(reservation_userid, reservation_itemid, reservation_qty, reservation_dollaramount)
                     VALUES('".$userid."', '".$item."', '".$qty."', '".$totalamt."')";
                
            if (mysqli_query($db, $query)) {
                $query = "select user_first, user_last from user where
                          user_id = '".$userid."'";
                $result = mysqli_query($db, $query);               
                
                while($row = mysqli_fetch_assoc($result)) {                
                    echo "Thank you ".$row["user_first"]." ".$row["user_last"]."! Your items will be 
                    waiting for you at the front desk when you arrive.";
                    echo "<br /><br /><br />";
                }

                $query = "SELECT reservation_id FROM reservation ORDER BY reservation_id DESC LIMIT 1";
                $result = mysqli_query($db, $query);               
                
                while($row = mysqli_fetch_assoc($result)) {  
                    echo "Reservation Number: ".$row["reservation_id"];
                    echo "<br /><br />";   
                }
            
                $query = "SELECT item_name FROM item WHERE item_id = '".$item."'";
                $result = mysqli_query($db, $query);               
                
                while($row = mysqli_fetch_assoc($result)) {  
                    echo "Item Reserved: ".$row["item_name"];
                    echo "<br /><br />"; 
                    echo "Quantity: ".$qty;
                    echo "<br /><br />";
                    echo money_format("Reservation Fee: $%i", $totalamt);
                    echo "<br /><br />";
                }
            } 
        }
    }
    else {
        echo "Sorry, your request exceeds the quantity on hand.  Please choose a lower quantity or select a different item.";
        echo "<br /><br /><br />";
    }   
}
else {
    echo "Error updating record: Please call the Community Sports Rental Center for further assistance.";
}

?>
    <br />
   
    <input type='button' onclick='location.href="select_item.php";' value='Reserve Another Item' />
    <input type='button' onclick='location.href="logout.php";' value='Log Out' />
    
</div>
</body>
</html>

