<?php

session_start();

$_SESSION['login'] = false;  //Not logged in

$uname = "";  //Initializes username, password, and error message variables to empty text string
$password= "";
$message="";

if (isset($_POST["submit"])){  //Runs following block when submit button pressed
    //Assigns username field to variable
    if (isset($_POST['name']))
        $uname=$_POST['name'];
    //Assigns password field to variable
    if (isset($_POST['password']))
        $password = $_POST['password'];
    
    
    if ((isset($_POST['name'])) || (isset($_POST['password']))) {
        
        //Connects to database
        define("HOST",'localhost');
        $mysql=mysqli_connect(HOST,'wp_user','password','ciss227');
        
        //If no connection can be made, assigns error message
        if(!$mysql) {
            $message= "        <p class='error'>Problem connecting to database.  Please try again later.</p>";
        }
        else { //If connection is made, runs query to see if there is a username and password match
            $query = "select count(*) from user where
                        user_username = '".$uname."' and
                        BINARY user_password = BINARY '".$password."' ";

            $result = mysqli_query($mysql, $query);
            $row = mysqli_fetch_row($result);
            $count = $row[0];  //Count is the number of matches.  Should be 1 if credentials are correct, 0 if not

            
            if ($count > 0) {  //If count is not 1, it is 1, so gets user_id from database
                $query = "select user_id from user where
                                user_username = '".$uname."' ";

                $result = mysqli_query($mysql, $query);               
                
                while($row = mysqli_fetch_assoc($result)) {                
                    $uid = $row["user_id"];
                    $_SESSION["userid"] = $uid;  //Assigns user_id to session variable, so it can be accessed on confirmation page
                    $_SESSION['login'] = true;  //Changes login flag to allow user to access other pages
                    
                    header("Location: select_item.php");  //Redirects to select item page
                }
            }
            else {  //If count of matches was zero, prints error message
                $message= "        <p class='error'>Invalid username and/or password.  Please re-enter credentials.</p>";
            }
        }
    }
}


include "header.php";

?>
    <div class="content">
        <h1>Please Log In To Reserve Equipment</h1>
        <p class="testing">For testing-</p>
        <p class="testing">Username: user (not case sensitive)</p>
        <p class="testing">Password: password (is case sensitive)</p>
        <form method="post" action="login.php">
            <p>Username: <input type="text" name="name" value="<?php echo $uname; ?>"></p>
            <p>Password: <input type="password" name="password"></p>
            <p><input type="submit" name="submit" value="Log In"></p>
        </form> 
     
    <?php
    if ($message!=""){  //Prints error message if message is not empty string
        echo $message;
    }
    ?>  
    </div>
</body>
</html>
