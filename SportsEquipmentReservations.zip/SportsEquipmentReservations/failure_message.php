<!DOCTYPE html>
<head>
    <title>Database Error</title>
    <link rel="stylesheet" type="text/css" href="item_inventory.css" />  
</head>
<body>
    <div id="banner">
        Community Sports Equipment Reservation System
    </div>

<?php

echo "<div id='results'>";
echo "<br />Database Error: Please call the Community Sports Rental Center for further assistance.";
echo "<br /><br /><input type='button' onclick='location.href=\"logout.php\";' value='Log Out'>";
echo "</div>";

?>