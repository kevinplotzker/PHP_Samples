<?php
   
session_start();
$_SESSION['item_id'] = $_POST['item_id'];
$it = $_POST['item_id'];
   
    if($it == 'NONE') {
        $redirectLocation = "select_item_error.php";
   }
    else {
        $redirectLocation = "write_xml.php";
    }
    
    header ("Location: ".$redirectLocation);
        
?>