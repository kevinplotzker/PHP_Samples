<!DOCTYPE html>
<head>
    <title>Equipment Reservations: Login</title>
    <link rel="stylesheet" type="text/css" href="item_inventory.css" />  
</head>
<body>
    <div id="banner">
        Community Sports Equipment Reservation System
    </div>
